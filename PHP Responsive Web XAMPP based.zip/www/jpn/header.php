<div class="header ">
    <div class="header_conts max_width">
        <img src="../img/logo.png?<?=$ver?>" class="logo link_btn" alt=""  onclick="location.href='index.php'">
        <div class="header_menus">
            <div class="hm_menu link_btn" onclick="location.href='introduce.php'">私は</div>
            <div class="hm_menu link_btn" onclick="location.href='bbs.php'">掲示板として</div>
            <div class="hm_menu link_btn" onclick="location.href='responsive1.php'">反応する 1</div>
            <div class="hm_menu link_btn" onclick="location.href='responsive2.php'">反応する 2</div>
            <div class="hm_menu link_btn" id="login">接続しよう</div>
            <div class="hm_menu link_btn" id="contact" onclick="location.href='inquiry.php'">お問い合わせ</div>
            <div class="hm_menu link_btn" id="cost" onclick="location.href='https://soundcloud.com/busterchaplin'">Sound Cloud</div>
            <div class="clear"></div>
        </div>
        <div class="ham">
            <div class="">
                <img class=" link_btn" src="../img/ham.png?<?=$ver?>" alt="">
            </div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<div class="mob_side_menus">
    <div class="msm_close">
        <img class="side_close_button link_btn" src="../img/side_close.png?<?=$ver?>" alt="">
    </div>
    <div class="msm_menu link_btn" onclick="location.href='introduce.php'">私は</div>
    <div class="msm_menu link_btn" onclick="location.href='bbs.php'">掲示板として</div>
    <div class="msm_menu link_btn" onclick="location.href='responsive1.php'">反応する 1</div>
    <div class="msm_menu link_btn" onclick="location.href='responsive2.php'">反応する 2</div>
    <div class="msm_menu msmm_last link_btn" id="mob_login">接続しよう</div>
    <!--
    <div class="msm_menu msmm_last link_btn">문의하기</div>
    -->
    <div class="msm_menu link_btn" id="contact" onclick="location.href='inquiry.php'">お問い合わせ</div>
    <div class="msm_menu link_btn" id="cost" onclick="location.href='https://soundcloud.com/busterchaplin'">Sound Cloud</div>
</div>
<div class="login">
    <div class="login_box">
        <div class="lb_top">
            <img class="lb_close link_btn" src="../img/login_x.png?<?=$ver?>" alt="">
        </div>
        <div class="login_body">
            <div class="lb_title">Login</div>
            <div class="lb_types">
                <div class="lbt_elem link_btn">Visitor</div>
                <div class="clear"></div>
            </div>
            <div class="lb_intro">E-mail</div>
            <input type="email" name="id" id="user_id" value="">
            <div class="lb_intro">Password</div>
            <input type="password" name="pw" id="user_pw" value="">
            <label class="lb_login_button link_btn" id="lb_login" onclick="ajax_login()">Login</label>
            <div class="lb_lost_find link_btn" id="lb_pf">Can't Remember ID or Password?</div>
            <div class="lb_join link_btn" id="lb_join">Join if First time</div>
        </div>
    </div>
</div>
<div class="pass_find">
    <div class="pf_box">
        <div class="pfb_top">
            <img class="pfb_close link_btn" src="../img/login_x.png?<?=$ver?>" alt="">
        </div>
        <div class="pf_body">
            <div class="pfb_title">Can't Remember Password?</div>
            <div class="pfb_desc">if you write E-mail below, will give Temporary Password</div>
            <div class="pfb_intro">E-mail</div>
            <input type="email" name="" value="">
            <label class="pfb_ask_button link_btn" id="pf_reset">Temporary Password</label>
            <div class="pfb_login_back link_btn" id="pf_login">Back To Login</div>
        </div>
    </div>
</div>
<div class="join">
    <div class="join_box">
        <div class="jb_top">
            <img class="jbt_close link_btn" src="../img/login_x.png?<?=$ver?>" alt="">
        </div>
        <div class="jb_body">
            <div class="jbb_title">Join</div>
            <div class="jbb_desc">Join with Email and use BBS</div>
            <div class="jbb_intro">Email as user ID</div>
            <input type="email" name="new_id" id="new_user_id" value="">
            <div class="jbb_intro">User Name</div>
            <input type="text" name="new_nick_name" id="new_user_nick_name" value="">
            <div class="jbb_intro">Password</div>
            <input type="password" name="new_pw" id="new_user_pw" value="">
            <div class="jbb_intro">Password Double Check</div>
            <input type="password" name="new_pw_repeat" id="new_user_pw_repeat" value="">
            <div class="jbb_intro">Captcha</div>
            <div class="jbb_captcha_wrap">
              <div class="jbbcw_left">
                <input type="text" name="captcha_match" id="captcha_input" value="">
              </div>
              <div class="jbbcw_right">
                <p id="captcha_display"></p>
              </div>
              <div class="clear"></div>
            </div>
            <label class="jbb_ask_button link_btn" id="jb_submit" onclick="ajax_join()">Submit</label>
            <div class="jbb_login_back link_btn" id="jb_login">Back To Login</div>
        </div>
    </div>
</div>

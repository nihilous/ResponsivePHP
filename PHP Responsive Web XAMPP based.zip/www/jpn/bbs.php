<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents max_width">
            <div class="mi_conts">
                <div class="mic_1">
                    <div class="mic1_top">
                        <div class="mic1t_left">
                            <div class="mic1tl_title"><b>AJAX </b>BBS Page</div>
                            <div class="mic1tl_desc">simply defenced anti query Injection</div>
                        </div>
                        <div class="mic1t_right">
                            <div class="mic1tr_title">Total Articles</div>
                            <div class="" id="mass_int_sum_num"> 숫자 </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="mic1_google">
                      <div>
                          <input type="text" name="bbs_title" class="mic1g_bbs_title" id="new_bbs_title" value="">
                      </div>
                      <div>
                          <textarea name="bbs_message"  class="mic1g_bbs_message" id="new_bbs_message" ></textarea>
                      </div>

                    </div>
                    <div class="mic1_bottom">
                        <div class="mic1b_line"></div>
                        <div class="mic1b_desc">if you want to post?</div>
                        <label class="mic1b_button" onclick="ajax_bbs_write()"><img src="" alt="">Submit</label>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="mic_2">
                    <div class="mic2_top">Ad Section Blank</div>
                    <div class="mic2_bottom">
                        <div class="mic2b_left">
                            <div class="mic2bl_top_ad">
                                <div class="mic2blta_closer">
                                    <img src="../img/mass_int_ad_close.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="mic2bl_bottom_trans_conts">

                              <div class="mic2blb_tc">
                                  <div class="mic2blb_tc_top">
                                      <div class="mic2blbtct_info">
                                          <span class="mic2blbtcti_ID"></span>
                                          <span class="mic2blbtcti_Time"><span>작성시간 </span><span class="mic2blbtctit_ymdt"></span></span>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="mic2blbtct_status">Delete</div>
                                      <div class="mic2blbtct_detail"></div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="mic2blb_tc_mid">
                                      <div class="mic2blbtcm_origin"></div>
                                      <div class="mic2blbtcm_translated"></div>
                                  </div>
                              </div>

                              <div class="mic2blb_tc">
                                  <div class="mic2blb_tc_top">
                                      <div class="mic2blbtct_info">
                                          <span class="mic2blbtcti_ID"></span>
                                          <span class="mic2blbtcti_Time"><span>작성시간 </span><span class="mic2blbtctit_ymdt"></span></span>
                                          <div class="clear"></div>
                                      </div>
                                      <div class="mic2blbtct_status">Delete</div>
                                      <div class="mic2blbtct_detail"></div>
                                      <div class="clear"></div>
                                  </div>
                                  <div class="mic2blb_tc_mid">
                                      <div class="mic2blbtcm_origin"></div>
                                      <div class="mic2blbtcm_translated"></div>
                                  </div>
                              </div>
                              <div class="mic2blb_tc_next" onclick="ajax_bbs_extra_road()" value="2">More</div>
                          </div>

                        </div>
                        <div class="mic2b_right">
                            <div class="mic2br_join">
                                <div class="mic2brj_top">Join Now</div>
                                <div class="mic2brj_desc"><a class="join_link cursor" href="#">Join</a> now and leave message.</div>
                            </div>
                            <div class="mic2br_ad_slide">Ad</div>
                            <div class="mic2br_ad_single">Ad</div>
                            <div class="mic2br_top_box">TOP</div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>

        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

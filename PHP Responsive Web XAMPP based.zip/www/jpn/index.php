<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
    <head>
      <?php
        include_once('./cdn.php');
      ?>
    </head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents">
            <div class="ic_1 max_width">
                <div class="ic1_Left">
                    <div class="ic1l_Title">言語を変換するインターネット</div>
                    <div class="ic1l_Desc" value="jpn">ヨンサマ</div>
                    <div class="ic1l_buttons">
                        <label class="ic1lb link_btn" id="cost" onclick="location.href='bbs.php'">Talk To</label>
                        <label class="ic1lb link_btn" id="intro" onclick="location.href='intro.php'">About Me</label>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="ic1_Right">
                    <img src="../img/ic1r.png?<?=$ver?>" alt="">
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_2 max_width">
                <div class="ic2_title"></div>
                <div class="ic2_elems">
                    <div class="ic2e_elem">
                        <img src="../img/ic2_1.png?<?=$ver?>" class="ic2ee_img" alt="">
                        <div class="ic2ee_title">HTML / CSS3</div>
                        <div class="ic2ee_desc">Modern Responsive Web Front</div>
                        <div class="ic2ee_link ">self studied</div>
                    </div>
                    <div class="ic2e_elem">
                        <img src="../img/ic2_2.png?<?=$ver?>" class="ic2ee_img" alt="">
                        <div class="ic2ee_title">JavaScript</div>
                        <div class="ic2ee_desc">ECMA based + jQuery, AJAX / Vue.JS , Axios</div>
                        <div class="ic2ee_link ">studying React</div>
                    </div>
                    <div class="ic2e_elem">
                        <img src="../img/ic2_3.png?<?=$ver?>" class="ic2ee_img" alt="">
                        <div class="ic2ee_title">PHP / MySQL</div>
                        <div class="ic2ee_desc">php + maria db + saved procedure</div>
                        <div class="ic2ee_link ">Studying Python</div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="ic_3">
                <div class="ic3_title">Show Off Section</div>
                <div class="ic3_top">
                    <div class="ic3t_elem">
                        <img src="../img/ic3_1.png?<?=$ver?>" alt="">
                        <div class="ic3e_title">Lorem ipsum</div>
                        <div class="ic3e_desc">Blah Blah</div>
                        <div class="ic3te_link link_btn">Blank Link</div>
                    </div>
                    <div class="ic3t_elem">
                        <img src="../img/ic3_2.png?<?=$ver?>" alt="">
                        <div class="ic3e_title">Lorem ipsum</div>
                        <div class="ic3e_desc">Blah Blah</div>
                        <div class="ic3te_link link_btn">Blank Link</div>
                    </div>
                    <div class="ic3t_elem">
                        <img src="../img/ic3_3.png?<?=$ver?>" alt="">
                        <div class="ic3e_title">Lorem ipsum</div>
                        <div class="ic3e_desc">Blah Blah</div>
                        <div class="ic3te_link link_btn">Blank Link</div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="ic3_bottom">
                    <div class="ic3b_elem">
                        <img src="../img/ic3_4.png?<?=$ver?>" alt="">
                        <div class="ic3e_title">Lorem ipsum</div>
                        <div class="ic3e_desc">Blah Blah</div>
                        <div class="ic3be_link link_btn">Blank Link</div>
                    </div>
                    <div class="ic3b_elem">
                        <img src="../img/ic3_5.png?<?=$ver?>" alt="">
                        <div class="ic3e_title">Lorem ipsum</div>
                        <div class="ic3e_desc">Blah Blah</div>
                        <div class="ic3be_link link_btn">Blank Link</div>
                    </div>
                    <div class="ic3b_elem">
                        <img src="../img/ic3_6.png?<?=$ver?>" alt="">
                        <div class="ic3e_title">Lorem ipsum</div>
                        <div class="ic3e_desc">Blah Blah</div>
                        <div class="ic3be_link link_btn">Blank Link</div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="ic_4">
                <div class="ic4_wrap max_width">
                    <div class="ic4w_left">
                        <div class="ic4wl_slider">
                            <div class="ic4wls_cont link_btn">
                                <div class="ic4wlsc_img">
                                    <div class="ic4wlsc_img_rounder">
                                    </div>
                                    <div class="ic4wlsc_img_rounder2">
                                        <img src="../img/ic4_c_1.png?<?=$ver?>" class="ic4wlcir2_img" alt="">
                                    </div>
                                </div>
                                <div class="ic4wlsc_client">
                                    <div class="ic4wlscc_desc">理解が速く、早く学ぶ.</div>
                                    <span class="ic4wlscc_name">イ・ソクジン</span>
                                    <span>-</span>
                                    <span class="ic4wlscc_company">ブレーブシニア Dev</span>
                                </div>
                            </div>
                        </div>
                        <div class="ic4wl_emmeters">
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_1" value="jpn" style="background-color:red;"></div>
                            <?php
                              $elem_count = 6;
                              for ($i = 2; $i <= $elem_count; $i++)
                              {
                                echo('<div class="ic4wle_elem link_btn" id="ic4wl_e_'.$i.'" value="kor"></div>');
                              }
                            ?>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="ic4w_right">
                        <div class="ic4wr_title">My Friends</div>
                        <div class="ic2wr_desc">They review what kind of person I am.</div>
                        <div class="ic4wr_link link_btn">Click descripsion section elements and see JS response</div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="ic_5 max_width">
                <div class="ic5_left">Show Off Section</div>
                <div class="ic5_right">
                    <div class="ic5r_row">
                        <div class="ic5rr_title">Lorem ipsum</div>
                        <div class="ic5rr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                        <div class="ic5rr_link link_btn">Blank Link</div>
                    </div>
                    <div class="ic5r_row">
                        <div class="ic5rr_title">Lorem ipsum</div>
                        <div class="ic5rr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                        <div class="ic5rr_link link_btn">Blank Link</div>
                    </div>
                    <div class="ic5r_row">
                        <div class="ic5rr_title">Lorem ipsum</div>
                        <div class="ic5rr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                        <div class="ic5rr_link link_btn">Blank Link</div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_6 max_width">
                <div class="ic6_left">
                    <img src="../img/ic6.png?<?=$ver?>" alt="">
                </div>
                <div class="ic6_right">
                    <div class="ic6r_title">Lorem ipsum</div>
                    <div class="ic6r_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                    <div class="ic6r_link link_btn"  onclick="location.href='#'">Blank Link</div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_7 max_width">
                <div class="ic7_left">
                    <div class="ic7l_title">If you feel curious about me? Speak to me directly.</div>
                    <div class="ic7l_desc">I'am ready to provide with a skillset</div>
                    <label class="link_btn" id="contact" onclick="location.href='inquiry.php'">Contact Me</label>
                </div>
                <div class="ic7_right">
                    <div class="ic7r_img ic7ri_url_1"></div>
                    <div class="ic7r_desc">Hello, I'm Yong Gun Park. Do you need my help?</div>
                    <div class=" ic7r_info">
                        <span class="ic7ri_name">Yong Gun Park</span>
                        <span>-</span>
                        <span class="ic7ri_position">Web Developer</span>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Lorem ipsum</div>
                    <div class="ic8l_desc">A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Blank Link</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

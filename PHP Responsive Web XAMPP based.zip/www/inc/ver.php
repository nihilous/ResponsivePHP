<?php
  session_start();

  // session_cache_expire(1800);
  $ver = "0.060";
?>

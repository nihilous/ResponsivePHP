<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="lab_contents">

            <div class="lc_1">
                <div class="lc1_wrap max_width">
                    <div class="lc1_left">
                        <div class="lc1l_title">Responsive Web Sample 2</div>
                        <div class="l1cl_desc">3 Different Depth for PC, Tablet, Mobile Device</div>
                    </div>
                    <div class="lc1_right">
                        <img class="lc1r_img" src="../img/ic1r.png?<?=$ver?>" alt="">
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="lc_4 max_width">
                <div class="lc4_left">Blah Blah</div>
                <div class="lc4_right">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                <div class="clear"></div>
            </div>
            <div class="lc_5 max_width">
                <div class="lc5_title">Lorem ipsum</div>
            </div>
            <div class="lc_6 max_width">
                <div class="lc6_left">
                    <div class="lc6l_title">Lorem ipsum</div>
                    <div class="lc6l_desc">this is <a href="#">Blank Link</a> got it?</div>
                    <div class="lc6l_ext link_btn">Blank Link</div>
                </div>
                <div class="lc6_right">
                    <img class="lc6r_img" src="../img/lc6.png?<?=$ver?>" alt="">
                </div>
                <div class="clear"></div>
            </div>
            <div class="lc_7 max_width">
                <div class="lc7_column">
                    <div class="lc7c_icon">
                        <img class="lc7ci_img" src="../img/lc7_1.png?<?=$ver?>" alt="">
                    </div>
                    <div class="lc7c_title">Lorem ipsum</div>
                    <div class="lc7c_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                    <div class="lc7c_ext link_btn">Blank Link</div>
                    <div class="lc7c_screen_shot">
                        <img class="lc7css_img" src="../img/lc7_2.png?<?=$ver?>" alt="">
                    </div>
                    <div class="lc7c_app_store">
                        <img class="lc7cas_img" src="../img/lc7_3.png?<?=$ver?>" alt="">
                    </div>
                </div>
                <div class="lc7_column">
                    <div class="lc7c_icon">
                        <img class="lc7ci_img" src="../img/lc7_1.png?<?=$ver?>" alt="">
                    </div>
                    <div class="lc7c_title">Lorem ipsum</div>
                    <div class="lc7c_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                    <div class="lc7c_ext link_btn">Blank Link</div>
                    <div class="lc7c_screen_shot">
                        <img class="lc7css_img" src="../img/lc7_2.png?<?=$ver?>" alt="">
                    </div>
                    <div class="lc7c_app_store">
                        <img class="lc7cas_img" src="../img/lc7_3.png?<?=$ver?>" alt="">
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="lc_8 max_width">

                <div class="lc8_right">
                    <div class="lc8r_left">
                        <img class="lc8rl_img" src="../img/lc8_r.png?<?=$ver?>" alt="">
                    </div>
                    <div class="lc8r_right">
                        <div class="lc8rr_title">Lorem ipsum</div>
                        <div class="lc8rr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                        <div class="lc8rr_ext link_btn">Blank Link</div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="lc8_left">
                    <img class="lc8l_img" src="../img/lc8_l.png?<?=$ver?>" alt="">
                </div>
                <div class="clear"></div>
            </div>
            <div class="lc_2">
                <div class="lc2_wrap max_width">
                    <div class="lc2_title">Lorem ipsum</div>
                    <div class="lc2_conts">
                        <div class="lc2c_elem">
                            <div class="lc2ce_img">
                                <img src="" alt="">
                            </div>
                            <div class="lc2ce_title">Blah Blah</div>
                            <div class="lc2ce_desc">whatever right? just empty section cannot be blank.</div>
                            <div class="link_btn lc2ce_link">
                                <a href="#">Blank Link</a>
                            </div>
                        </div>
                        <div class="lc2c_elem">
                            <div class="lc2ce_img">
                                <img src="" alt="">
                            </div>
                            <div class="lc2ce_title">Blah Blah</div>
                            <div class="lc2ce_desc">whatever right? just empty section cannot be blank.</div>
                            <div class="link_btn lc2ce_link">
                                <a href="#">Blank Link</a>
                            </div>
                        </div>
                        <div class="lc2c_elem">
                            <div class="lc2ce_img">
                                <img src="" alt="">
                            </div>
                            <div class="lc2ce_title">Blah Blah</div>
                            <div class="lc2ce_desc">whatever right? just empty section cannot be blank.</div>
                            <div class="link_btn lc2ce_link">
                                <a href="#">Blank Link</a>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <div class="lc_9 max_width">
                <div class="lc9_title">Lorem ipsum</div>
                <div class="lc9_elems">
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="lc9e_elem">
                        <div class="lc9ee_title">Blah Blah</div>
                        <div class="lc9ee_desc">whatever right? just empty section cannot be blank.</div>
                        <div class="lc9ee_ext">
                            <a href="#">Blank Link</a>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="lc_3 max_width">
                <div class="lc3_left">Git Link</div>
                <div class="lc3_right">
                    <div class="">2017 Unity 3D learning camp, 2D, 3D portfolio link, ver 5.5.3 </div>
                </div>
                <div class="clear"></div>
                <div class="lc3_lists">
                    <div class="lc3l_elem link_btn" onclick="location.href='https://github.com/nihilous/2D-platformer-RPG--3D-strategy-boardgame-Portfolio/tree/master/2D%20%ED%94%8C%EB%9E%AB%ED%8F%AC%EB%A8%B8%20RPG%20script'">
                        <div class="lc3le_title">Unity 3D 2D platformer game</div>
                        <div class="lc3le_desc">C# codes based, Unity 3D gamecodes</div>
                    </div>
                    <div class="lc3l_elem link_btn" onclick="location.href='https://github.com/nihilous/2D-platformer-RPG--3D-strategy-boardgame-Portfolio/tree/master/3D%20%EC%A0%84%EB%9E%B5%EB%B3%B4%EB%93%9C%EA%B2%8C%EC%9E%84%20script'">
                        <div class="lc3le_title">Unity 3D 3D board game</div>
                        <div class="lc3le_desc">C# codes based, Unity 3D gamecodes</div>
                    </div>

                </div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Lorem ipsum</div>
                    <div class="ic8l_desc">A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Blank Link</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

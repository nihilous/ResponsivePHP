<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents">
            <div class="ic_1 max_width">
                <div class="ic1_Left">
                    <div class="ic1l_Title">
                      Grappler<br />
                      Musician<br />
                      Web Dev<br />
                    </div>
                    <div class="ic1l_Desc">Full time daydreamer</div>
                    <div class="ic1l_buttons">
                        <label class="ic1lb link_btn" id="cost" onclick="location.href='https://github.com/nihilous?tab=repositories'">C# G I T</label>
                        <label class="ic1lb link_btn" id="contact">Blank Link</label>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="ic1_Right">
                    <img src="../img/ic1r.png?<?=$ver?>" alt="">
                </div>
                <div class="clear"></div>
            </div>
            <div class="company_contents max_width">
                <div class="cc_1">
                    <div class="cc1_left">How did I Stranded Here</div>
                    <div class="cc1_right">
                        <div class="cc1r_elem">
                            <div class="cc1re_top">
                                <div class="cc1ret_img_rounder"></div>
                                <div class="cc1ret_title link_btn" onclick="location.href='#'">2nd Child</div>
                                <div class="clear"></div>
                            </div>
                            <div class="cc1re_bottom">Born 1988, Seoul, Korea, one older sister, spoiled loved child.</div>
                        </div>
                        <div class="cc1r_elem">
                            <div class="cc1re_top">
                                <div class="cc1ret_img_rounder"></div>
                                <div class="cc1ret_title link_btn" onclick="location.href='#'">Introverted Bookworm</div>
                                <div class="clear"></div>
                            </div>
                            <div class="cc1re_bottom">Surrounded by sister and cousin sisters, most of early childhood, I spent time reading books, play NES mario bros.</div>
                        </div>
                        <div class="cc1r_elem">
                            <div class="cc1re_top">
                                <div class="cc1ret_img_rounder"></div>
                                <div class="cc1ret_title link_btn" onclick="location.href='#'">Pro Wrestling</div>
                                <div class="clear"></div>
                            </div>
                            <div class="cc1re_bottom">in Teenage, boys my age were crazy for WWE Pro Wrestling, it was first thing I waited every week.</div>
                        </div>
                    </div>
                    <div class="cc1_right">
                        <div class="cc1r_elem">
                            <div class="cc1re_top">
                                <div class="cc1ret_img_rounder"></div>
                                <div class="cc1ret_title link_btn" onclick="location.href='#'">Music Lover</div>
                                <div class="clear"></div>
                            </div>
                            <div class="cc1re_bottom">I turned out to be extroverted, and started to play instruments deeply into music most USA, UK, Japan.</div>
                        </div>
                        <div class="cc1r_elem">
                            <div class="cc1re_top">
                                <div class="cc1ret_img_rounder"></div>
                                <div class="cc1ret_title link_btn" onclick="location.href='#'">No Job after  College</div>
                                <div class="clear"></div>
                            </div>
                            <div class="cc1re_bottom">after graduate Musical college, I got no job in studio,A&R so, worked in theater as projectionist, while studying in  university.</div>
                        </div>
                        <div class="cc1r_elem">
                            <div class="cc1re_top">
                                <div class="cc1ret_img_rounder"></div>
                                <div class="cc1ret_title link_btn" onclick="location.href='#'">Marriage</div>
                                <div class="clear"></div>
                            </div>
                            <div class="cc1re_bottom">met my soul mate from Finland, and we married, after quit theater job, my friend recommended  me to learn programming, since he  knows I'm geek. and I liked it a lot.</div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="cc_2">
                    <div class="ic_6">
                        <div class="ic6_left">
                            <img src="../img/cc2_ic6.png?<?=$ver?>" alt="">
                        </div>
                        <div class="ic6_right">
                            <div class="ic6r_title">Translation Matching System</div>
                            <div class="ic6r_desc">We make better world where leading clients and excellent translators are directly connected.</div>
                            <div class="ic6r_link link_btn">자세히 알아보기</div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="cc_3">
                        <div class="ic3_left">Excellence begins with the process</div>
                        <div class="ic3_right">
                                <div class="ic3r_desc">We are working hard to make the translation service more effective by strengthening the production process with great technology and talented personnel.</div>
                                <div class="ic3r_link link_btn">생산 프로세스</div>

                        </div>
                        <div class="clear"></div>
                </div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Lorem ipsum</div>
                    <div class="ic8l_desc">A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Blank Link</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

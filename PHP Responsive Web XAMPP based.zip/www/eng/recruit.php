<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="recruit_contents">
            <div class="rc_title max_width">
                <div class="rc_title">Job Search History</div>
                <div class="rc_date">Since I came to Finalnd July 2020</div>
            </div>
            <div class="rc_1 max_width">
                <div class="rc1_left">Sent CV Previously</div>
                <div class="rc1_right">
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Wapice</div>
                        <div class="rc1rp_link"><a href="#">Wapice Ltd Mobile and Web Application Designers
/ Web Front-End Development</a>(Turku)</div>
                    </div>
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Columbia Road</div>
                        <div class="rc1rp_link"><a href="#">Summer Internship</a>(Turku)</div>
                    </div>
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Digia</div>
                        <div class="rc1rp_link"><a href="#">Summer Internship</a>(Turku)</div>
                    </div>
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Eneroc</div>
                        <div class="rc1rp_link"><a href="#">Summer Internship</a>(Turku)</div>
                    </div>
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Loikka</div>
                        <div class="rc1rp_link"><a href="#">Summer Internship</a>(Turku)</div>
                    </div>
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Lyyti</div>
                        <div class="rc1rp_link"><a href="#">Summer Internship</a>(Turku)</div>
                    </div>
                    <div class="rc1r_position">
                        <div class="rc1rp_name">Taiste</div>
                        <div class="rc1rp_link"><a href="#">Summer Internship</a>(Turku)</div>
                    </div>
                </div>
                <div class="clear">

                </div>
            </div>
            <div class="translator_contents max_width">
                <div class="tc_1">
                    <div class="tc1_left">Education</div>
                    <div class="tc1_right">
                        <div class="rc2_desc">
                            <div class="rc2d_title">TAITO</div>
                            <div class="rc2d_desc">Integration Course</div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Basic Finnish Language</div>
                            <div class="tc1rr_link link_btn ">A2.1 ~ A2.2</div>
                            <!-- 클릭하면 이미지 띄우기 어학성적 -->
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Summer Internship in Puorenkuun Pelit Turku</div>
                            <div class="tc1rr_link link_btn "> </div>
                            <!-- 클릭하면 이미지 띄우기 어학성적 -->
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Learning about Finnish Culture</div>
                            <!-- 클릭하면 이미지 띄우기 어학성적 -->
                            <div class="clear"></div>
                        </div>

                        <label class="rc2_apply_button link_btn">Blank Link</label>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
<!--
            <div class="company_contents max_width">
                <div class="cc_3">
                        <div class="ic3_left">Lorem ipsum</div>
                        <div class="ic3_right">
                                <div class="ic3r_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                                <label class="rc3_mou_button link_btn">Blank Link</label>
                        </div>
                        <div class="clear"></div>
                </div>

            </div>

            <div class="ic_6 max_width">
                <div class="ic6_left">
                    <img src="../img/ic6.png?<?=$ver?>" alt="">
                </div>
                <div class="ic6_right">
                    <div class="ic6r_title">Lorem ipsum</div>
                    <div class="ic6r_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                    <div class="ic6r_link link_btn">Blank Link</div>
                </div>
                <div class="clear"></div>
            </div>
          -->
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="quiry_contents">
            <!--
            <div class="qc_title max_width">문의하기</div>
            -->
            <div class="qc1 max_width">
                <div class="qc1_title">Contact to YongGun Park</div>
                <div class="qc1_inst">Guaranteed answer by today at 7:00 PM. <br />will be replied by</div>
                <div class="qc1_contact"><img src="" alt="">dkfg123@gmail.com</div>
            </div>
            <div class="qc2 max_width">
                <div class="qc2_left">
                    <label class="qc2l_title">Email Address</label>
                    <div class="qc2l_input_space">
                        <input class="qc2lis_input" type="email" name="" value="" placeholder="예) email@example.com">
                    </div>
                    <label class="qc2l_title">Enter your name</label>
                    <div class="qc2l_input_space">
                        <input class="qc2lis_input" type="text" name="" value="" placeholder="예) John Doe">
                    </div>
                    <!--
                    <label class="qc2l_title">Upload files</label>
                    <div class="qc2l_input_space">
                        <label class="qc2lis_file_button" for="inquiry_file">FILE</label>
                        <input class="qc2lis_input" type="file" id="inquiry_file" name="" value="">
                    </div>
                    -->
                    <label class="qc2l_title">Message</label>
                    <div class="qc2l_input_space">
                        <textarea class="qc2l_text" name="name" rows="8" cols="80" placeholder="Write a message..."></textarea>
                    </div>
                    <div class="qc2l_agree">
                        <input type="checkbox" name="" value="">
                        <label for="">I have read and agree to the <a href="privacypolicy.php">Privacy Policy</a></label>
                    </div>
                    <div class="qc2submit">Send</div>
                </div>
                <div class="qc2_right">
                    <div class="qc2r_title">Residency Information</div>
                    <div class="qc2r_row">
                        <div class="qc2rr_left">
                            <img src="../img/qc2rrl_icon.png?<?=$ver?>" alt="">
                        </div>
                        <div class="qc2rr_right">
                            <div class="qc2rrr_1">Spouse Visa</div>
                            <div class="qc2rrr_2">~ 01. 25. 2025</div>
                            <div class="qc2rrr_3">Finnish Residence Permit</div>
                            <div class="qc2rrr_4 link_btn"><a href="https://www.google.com/maps/place/Puutarhakatu+18,+20100+Turku/@60.4497214,22.2517603,17z/data=!3m1!4b1!4m5!3m4!1s0x468c76ff60559ecd:0xa3f5cb68eeb5cd3!8m2!3d60.4497214!4d22.253949" target="_blank">Location View Map</a></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="qc2r_contact">
                        <div class="qc2rc_title">Give us a call</div>
                        <div class="qc2rc_status">
                            <div class="qc2rcs_desc">We’re not online now. Please send us an email or leave a voice message.</div>
                            <div class="qc2rcs_icon"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="qc2rc_phone"><img src="../img/qc2_contact.png?<?=$ver?>" alt="">+358-45-279-7542</div>
                        <div class="qc2rc_reg">Show other available numbers</div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="qc_phone_digit">
                <div class="qcpd_top">
                    <div class="qcpdt_close">
                        <img src="../img/login_x.png?<?=$ver?>" alt="">
                    </div>
                    <div class="qcpdt_title">Give us a call</div>

                </div>
                <div class="qcpd_info">

                    <div class="qcpdi_row">
                        <div class="qcpdir_country">Wife</div>
                        <div class="qcpdir_numbers">+358-45-279-7547</div>
                    </div>
                    <div class="qcpdi_row">
                        <div class="qcpdir_country">Republic of Korea</div>
                        <div class="qcpdir_numbers">+82-10-5667-2211</div>
                    </div>
                    <div class="clear"></div>
                </div>

            </div>

        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

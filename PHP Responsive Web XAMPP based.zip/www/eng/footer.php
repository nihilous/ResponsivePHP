<div class="footer max_width">
    <div class="f_left">
        <div class="fl_img"></div>
        <div class="fl_desc">
            <div class="fld_top">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>

        </div>
        <div class="clear"></div>
    </div>
    <div class="f_middle">
        <div class="fm_links">
            <div class="fml_elem link_btn" id="" onclick="location.href='faq.php'">FAQ</div>
            <div class="fml_elem link_btn" id="" onclick="location.href='recruit.php'">Job Search Record</div>
            <div class="fml_elem link_btn" id="" onclick="location.href='function.php'">What's new</div>
        </div>
    </div>

    <div class="f_right">
        <div class="">
            <select class="fr_language" onchange="location.href=this.value">
                <option selected="selected" value="../eng/index.php" id="frl_eng">English</option>
                <option value="../kor/index.php" id="frl_kor">한국어</option>
                <option value="../jpn/index.php" id="frl_jpn">日本語</option>
            </select>
        </div>



        <div class="fr_phone">
            <img src="../img/footer_contact_1.png?<?=$ver?>" alt="">
            <div class="frp_numbers">+358-45-279-7542</div>
            <div class="clear"></div>
        </div>
        <div class="fr_email">
            <img src="../img/footer_contact_2.png?<?=$ver?>" alt="">
            <div class="fre_address">dkfg123@gmail.com</div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="clear">
        <div class="f_info">Can We Be Colligue?</div>
    </div>
</div>

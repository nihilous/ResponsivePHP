<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents">
            <div class="function_contents">
                <div class="fc_1 max_width">
                    <div class="fc1_title">Sample Responsive Page</div>
                    <div class="fc1_desc">Ready Varies Responsive Depth in Future, if you want.</div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_left">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_right">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_right">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_left">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_left">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_right">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_3">
                    <div class="fc3_title">Title</div>
                    <div class="fc3_desc">Desc</div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_right">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_left">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_left">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_right">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_right">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_left">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_2 max_width">
                    <div class="fc2_left">
                        <div class="fc2_title">Title</div>
                        <div class="fc2_desc">Desc</div>
                    </div>
                    <div class="fc2_right">
                        <img src="../img/func2.png?<?=$ver?>" alt="">
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="fc_3">
                    <div class="fc3_title">Title</div>
                    <div class="fc3_desc">Desc</div>
                </div>

            </div>
            <div class="ic_6 max_width">
                <div class="ic6_left">
                    <img src="../img/ic6.png?<?=$ver?>" alt="">
                </div>
                <div class="ic6_right">
                    <div class="ic6r_title">Blah Blah</div>
                    <div class="ic6r_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                    <div class="ic6r_link link_btn">Blank Link</div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Blank</div>
                    <div class="ic8l_desc">A B C D E F G H I J K L M O P Q R S T U V W X Y Z</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Blank Link</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

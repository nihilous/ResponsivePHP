<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents">

            <div class="affiliate_contents max_width">

                <div class="ac_1">파트너 프로그램</div>

                <div class="ac_2">
                    <div class="ac2_left">제휴 프로그램</div>
                    <div class="ac2_right">
                        <div class="ac2r_desc">
                            <div class="ac2rd_row">Textmined의 제휴 프로그램은 사이트의 광고 수입을 늘리는 스마트한 방법입니다.</div>
                            <div class="ac2rd_row">사용자가 지불한 모든 주문 건에 대해 10%를 지불합니다.</div>
                        </div>
                        <div class="ac2r_links">
                            <label id="affiliate_login" class="ac2rl_login link_btn">로그인</label>
                            <label id="" class="ac2rl_join link_btn"  onclick="location.href='join.php'">회원가입</label>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>

                <div class="ac_2">
                    <div class="ac2_left">번역 파트너 프로그램</div>
                    <div class="ac2_right">
                        <div class="ac2r_desc">
                            <div class="ac2rd_row">파트너 프로그램은 개인 및 기업이 세계 정상급 번역 서비스를 시장에 내놓을 수 있는 흥미로운 비즈니스 기회입니다.</div>
                            <div class="ac2rd_row">Textmined와의 협력을 통해 파트너는 자사의 핵심 역량에서 벗어난 생산 능력에 부담을 주는 프로젝트를 수행하는 것에 대한 두려움 없이 강점을 개발하는 데 집중할 수 있습니다.</div>
                            <div class="ac2rd_row">공식적으로 요구되는 초기 투자는 없습니다. 그러나 사업 계획에 할당된 예산과 시간을 기준으로 목표를 정합니다.</div>
                        </div>
                        <div class="ac2r_links">
                            <label id="" class="ac2rl_inquiry link_btn">문의하기</label>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="ic_7 max_width">
                <div class="ic7_left">
                    <div class="ic7l_title">큰 프로젝트를 진행하십니까? CEO와 직접 논의하십시오.</div>
                    <div class="ic7l_desc">우리 팀은 귀하의 번역 요구에 대한 솔루션을 찾을 준비가되었습니다.</div>
                    <label class="link_btn" id="contact" onclick="location.href='inquiry.php'">문의하기</label>
                </div>
                <div class="ic7_right">
                    <div class="ic7r_img ic7ri_url_1"></div>
                    <div class="ic7r_desc">안녕하세요, 저는 Ethan입니다. 무엇을 도와드릴까요?</div>
                    <div class=" ic7r_info">
                        <span class="ic7ri_name">Ethan Nam</span>
                        <span>-</span>
                        <span class="ic7ri_position">대표이사</span>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">실시간 견적 받기</div>
                    <div class="ic8l_desc">빠른 주문 방식으로 즉각적인 번역을 받으십시오. 몇 번의 클릭만으로 온라인 구매가능.</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">실시간 견적</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

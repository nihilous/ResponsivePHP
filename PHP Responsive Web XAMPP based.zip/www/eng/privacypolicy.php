<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="pp_contents max_width">
            <div class="ppc_title">Privacy and Cookie Policies</div>
            <div class="ppc_date">Year Month Date</div>
            <ul class="ppc_list">
                <li class="ppcl_title">Blah Blah 1</li>
                <div class="ppcl_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                <div class="ppcl_inner_list">
                    <ul class="ppclil_ul">
                        <li class="ppclil_empha">Emphasize 1</li>
                        <li class="ppclil_empha">Emphasize 2</li>
                    </ul>
                </div>
                <li class="ppcl_title">Blah Blah 2</li>
                <div class="ppcl_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                <div class="ppcl_inner_list">
                    <ul class="ppclil_ul">
                        <li class="ppclil_empha">Emphasize 1</li>
                        <li class="ppclil_empha">Emphasize 2</li>
                    </ul>
                </div>
                <li class="ppcl_title">Blah Blah 3</li>
                <div class="ppcl_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                <div class="ppcl_inner_list">
                    <ul class="ppclil_ul">
                        <li class="ppclil_empha">Emphasize 1</li>
                        <li class="ppclil_empha">Emphasize 2</li>
                    </ul>
                </div>
            </ul>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

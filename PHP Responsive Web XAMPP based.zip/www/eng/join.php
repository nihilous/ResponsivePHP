<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="join_contents">
            <div class="jc_1 max_width">Join a global team... register now!</div>
            <div class="jc_2 max_width">
                <span>409959</span>
                <span>translators</span>
                <span>4261</span>
                <span>language combinations</span>
                <span>149621</span>
                <span>customers</span>
            </div>
            <div class="jc_3 max_width">
                <div class="jc3_left">
                    <div class="jc3l_top">New Users:</div>
                    <div class="jc3l_input_elem">
                        <div class="jc3lie_left">1) Choose a username:</div>
                        <input class="jc3lie_right" type="text" name="" value="">
                        <div class="clear"></div>
                    </div>
                    <div class="jc3l_input_elem">
                        <div class="jc3lie_left">2) Choose a password:</div>
                        <input class="jc3lie_right" type="password" name="" value="">
                        <div class="clear"></div>
                    </div>
                    <div class="jc3l_input_elem">
                        <div class="jc3lie_left">3) Confirm password:</div>
                        <input class="jc3lie_right" type="password" name="" value="">
                        <div class="clear"></div>
                    </div>
                    <div class="jc3l_input_elem">
                        <div class="jc3lie_left">4) Enter your email:</div>
                        <input class="jc3lie_right" type="email" name="" value="">
                        <div class="clear"></div>
                    </div>
                    <div class="jc3l_links">By registering I accept the <a class="link_btn" href="termcondition.php">Terms and Conditions</a> and the <a class="link_btn" href="privacypolicy.php">Privacy Policy</a></div>
                    <div class="jc3l_button_space">
                        <label class="jc3ls_button link_btn" for="">Register</label>
                    </div>

                </div>
                <div class="jc3_right">
                    <div class="jc3r_top">Registration takes 10 mins:</div>
                    <div class="jc3r_middle">We need your...</div>
                    <ul class="jc3r_bottom">
                        <li class="jc3rb_elem">Personal details</li>
                        <li class="jc3rb_elem">Experience & skills</li>
                        <li class="jc3rb_elem">Languages & rates</li>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

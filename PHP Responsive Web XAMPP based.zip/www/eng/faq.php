<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="faq_contents">
            <div class="faqc_title max_width">Frequently Asked Questions</div>
            <div class="faqc_body max_width">
                <div class="faqcb_conts">
                    <div class="faqcbc_title">Ordinary</div>
                    <div class="faqcbc_desc" id="faq_1_1">
                        <div class="faqcbcd_question">
                            <div class="faqcbcdq_left">You didn't major in computer science?</div>
                            <img class="faqcbcdq_right link_btn" src="../img/faq.png?<?=$ver?>" alt="" value="<?=$ver?>">
                            <div class="clear"></div>
                        </div>
                        <div class="faqcbcd_answer">does majoring in computer science meaning better web developer?, while I was in Unity 3D bootcamp, as none major developer, I was group leader as helped Computer Science B.D</div>
                    </div>
                    <div class="faqcbc_desc" id="faq_1_2">
                        <div class="faqcbcd_question">
                            <div class="faqcbcdq_left">Why Finland?</div>
                            <img class="faqcbcdq_right link_btn" src="../img/faq.png?<?=$ver?>" alt="" value="<?=$ver?>">
                            <div class="clear"></div>
                        </div>
                        <div class="faqcbcd_answer">My wife is Finnish person, and I love here, we lived in South Korea 5years together, and she wanted to continue her study in Finland, and I wanted new adventure.</div>
                    </div>
                    <div class="faqcbc_desc" id="faq_1_3">
                        <div class="faqcbcd_question">
                            <div class="faqcbcdq_left">What is your Biggest fear in work?</div>
                            <img class="faqcbcdq_right link_btn" src="../img/faq.png?<?=$ver?>" alt="" value="<?=$ver?>">
                            <div class="clear"></div>
                        </div>
                        <div class="faqcbcd_answer">I know nothing about design, may be can crop images on photoshop? that's all. but if you tell me to steal fine design web page, I can be a good copycat. or hire disigner!</div>
                    </div>
                </div>

                <div class="faqcb_conts">
                    <div class="faqcbc_title">Tech</div>
                    <div class="faqcbc_desc" id="faq_2_1">
                        <div class="faqcbcd_question">
                            <div class="faqcbcdq_left">have you ever developed Apple, Android web app before?</div>
                            <img class="faqcbcdq_right link_btn" src="../img/faq.png?<?=$ver?>" alt="" value="<?=$ver?>">
                            <div class="clear"></div>
                        </div>
                        <div class="faqcbcd_answer">no, I haven't but I know the conception. make responsive web program and embrace it with native script like framework, also have experience of compile APK file through Unity 3D, mobile game</div>
                    </div>
                    <div class="faqcbc_desc" id="faq_2_2">
                        <div class="faqcbcd_question">
                            <div class="faqcbcdq_left">what else, are you interested of?</div>
                            <img class="faqcbcdq_right link_btn" src="../img/faq.png?<?=$ver?>" alt="" value="<?=$ver?>">
                            <div class="clear"></div>
                        </div>
                        <div class="faqcbcd_answer">web crawling using Python, and making macro with it or process data through it. I have huge interest</div>
                    </div>
                    <div class="faqcbc_desc" id="faq_2_3">
                        <div class="faqcbcd_question">
                            <div class="faqcbcdq_left">can you work with Unity 3D?</div>
                            <img class="faqcbcdq_right link_btn" src="../img/faq.png?<?=$ver?>" alt="" value="<?=$ver?>">
                            <div class="clear"></div>
                        </div>
                        <div class="faqcbcd_answer">if you give me time to catch up new documents and remind things yes.</div>
                    </div>
                </div>
            </div>

            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Lorem ipsum</div>
                    <div class="ic8l_desc">A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Blank Link</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

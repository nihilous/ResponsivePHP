<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents">
            <div class="reference_contents max_width">
                <div class="rc_1">
                    <div class="rc1_title">From innovative startups to multinationals</div>
                    <div class="rc1_desc">Serving 157,579 clients worldwide, we partner with businesses of every size, adapting from small, on-demand tasks to high touch, fully managed solutions.</div>
                </div>

                <div class="rc_2">
                    <div class="rc2_left">Case studies</div>
                    <div class="rc2_right">
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Textmined makes the process of website localization simple, with affordable rates, expert native-speaking translators, and a cutting-edge translation platform.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">The world is going mobile – in fact, it already has. Still, the app economy is expected to double in size to $189 billion by 2020, according to market research site Statista. Textmined makes app localization quick, easy and affordable.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Textmined is integrated with leading technology platforms like Youtube, Amazon, etc. Find a complementary service or technology to add professional translation to your workflow.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">We offer fast, accurate and confidential transcription for audio, video, plain text and subtitles across 36 languages, add-ons including faster turnaround time, multilingual audio, timestamps and additional file types.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Whether a simple typo or a more complex grammatical error, our qualified proofreaders check and double check your text to ensure it’s perfect. We fix errors based on language structure, punctuation, grammar, consistency, format, structure and style.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Our native workers will assess your text or audio files to determine whether they reach your agreed criteria and quality standards, including checking of machine-generated audio speech to decide whether it sounds natural, or selection of the most relevant comments in a text.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">We can score the quality of previously machine-translated segments or fix any errors to produce natural, error-free translations. Additional checks include the adherence of instructions or glossaries, the correct usage of voice and style, as well as the selection of the best version of a translation.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">We can score the quality of previously machine-translated segments or fix any errors to produce natural, error-free translations. Additional checks include the adherence of instructions or glossaries, the correct usage of voice and style, as well as the selection of the best version of a translation.</div>
                        </div>
                    </div>
                    <div class="rc2_right">
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Our crowd carefully transforms complicated text—supplied by the customer as URL or document—into short, digestible summaries, saving you time and preventing information overload when sharing with others.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">모바일 앱 또는 데스크톱 소프트웨어의 원본 파일을 현지화하고 테스트하여 복사 및 붙여 넣기의 어려움을 덜어줍니다.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">We provide classification of your content in the appropriate categories including tagging with relevant keywords. Whether your needs are categorization for images, product descriptions or websites, we ensure your content is categorized quickly and accurately.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Our expert copywriters will work their magic on almost any type of content including blog posts, website content, press releases, emails, social media content, white papers and taglines, to help you convert traffic into leads and finally, customers.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Other content creation for more specific needs, including the creation of variations of a particular sentence; potential questions, answers and conversation templates for chatbots; as well as blacklisting inappropriate words or phrases that are unsuitable for your audience.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">We can determine whether content is positive, negative or neutral by extracting particular words or phrases. Commonly used to discover how people feel about a particular topic, it can be implemented in social media, customer support, user feedback, user reviews and chatbots.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">Our language experts can check and review sponsored listings against a set of specific guidelines determined by the client. Regularly used as part of pay-per-click search advertising programs on ecommerce, travel and hotel listing sites, our review team can also analyze ads with custom copy, localized ad copy, or without any copy.</div>
                        </div>
                        <div class="rc2r_elem">
                            <div class="rc2re_top">
                                <div class="rc2ret_img_rounder">
                                    <img src="../img/rc2.png?<?=$ver?>" alt="">
                                </div>
                            </div>
                            <div class="rc2re_bottom">We can score the quality of previously machine-translated segments or fix any errors to produce natural, error-free translations. Additional checks include the adherence of instructions or glossaries, the correct usage of voice and style, as well as the selection of the best version of a translation.</div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="ic_4">
                <div class="ic4_wrap max_width rc3_ic4_wrap">

                    <div class="ic4w_left rc3ic4w_left">
                        <div class="ic4wl_slider">
                            <div class="ic4wls_cont">
                                <div class="ic4wlsc_img">
                                    <div class="ic4wlsc_img_rounder">
                                    </div>
                                    <div class="ic4wlsc_img_rounder2">
                                        <img src="../img/ic4_c_1.png?<?=$ver?>" class="ic4wlcir2_img" alt="">
                                    </div>
                                </div>
                                <div class="ic4wlsc_client  link_btn">
                                    <div class="ic4wlscc_desc">Seattle startup AppSheet is the world's leading no-coding application platform company, a leader in The Forrester Wave™ : Low-Code Platforms For Business Developers, Q2 2019 and has raised $19.3 million to fuel growth of its platform.</div>
                                    <span class="ic4wlscc_name">CEO Praveen Seshadri</span>
                                    <span>-</span>
                                    <span class="ic4wlscc_company">www.appsheet.com</span>
                                </div>
                            </div>
                        </div>
                        <div class="ic4wl_emmeters">
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_1" value="eng" style="background-color:red;"></div>
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_2" value="eng"></div>
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_3" value="eng"></div>
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_4" value="eng"></div>
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_5" value="eng"></div>
                            <div class="ic4wle_elem link_btn" id="ic4wl_e_6" value="eng"></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="ic_6 max_width">
                <div class="ic6_left">
                    <img src="../img/ic6.png?<?=$ver?>" alt="">
                </div>
                <div class="ic6_right">
                    <div class="ic6r_title">Becoming one of us</div>
                    <div class="ic6r_desc">We are ready to support you to become a better translator. Get the chance to choose projects you love to work on, at your own pace and deciding your own rate. We provide our high-end technology for free.</div>
                    <div class="ic6r_link link_btn"  onclick="location.href='intro.php'">About us</div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Get a real-time quote</div>
                    <div class="ic8l_desc">Translate instantly using our fast order form. Buy online with just a few clicks.</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Real-time quote</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

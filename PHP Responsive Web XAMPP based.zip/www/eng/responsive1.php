<?php
  include_once('../inc/ver.php');
?>
<!doctype html>
<html itemscope="" itemtype="http://schema.org/WebPage" lang="ko">
<head>
  <?php
    include_once('./cdn.php');
  ?>
</head>
    <body>
        <?php
            include_once("./header.php");
        ?>
        <div class="index_contents">
            <div class="ic_1 max_width">
                <div class="ic1_Left">
                    <div class="ic1l_Title">Responsive Web Sample 1</div>
                    <div class="ic1l_Desc">3 Different Depth for PC, Tablet, Mobile Device</div>
                    <div class="ic1l_buttons">
                        <label class="ic1lb link_btn" id="translator" onclick="location.href='join.php'">Next Responsive Page</label>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="ic1_Right">
                    <img src="../img/ic1r.png?<?=$ver?>" alt="">
                </div>
                <div class="clear"></div>
            </div>
            <div class="translator_contents max_width">
                <div class="tc_1">
                    <div class="tc1_left">Lorem ipsum</div>
                    <div class="tc1_right">
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah &nbsp;</div>
                            <div class="tc1rr_link link_btn" onclick="location.href='#'">Blank Link.</div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah.</div>
                            <div class="tc1rr_link link_btn tc1rr_link_hidden"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah.</div>
                            <div class="tc1rr_link link_btn tc1rr_link_hidden"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah.</div>
                            <div class="tc1rr_link link_btn tc1rr_link_hidden"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah.</div>
                            <div class="tc1rr_link link_btn tc1rr_link_hidden"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc1r_row">
                            <img class="tc1rr_icon" src="../img/tc1.png?<?=$ver?>" alt="">
                            <div class="tc1rr_desc">Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah Blah.</div>
                            <div class="tc1rr_link link_btn tc1rr_link_hidden"></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="translator_contents">
                <div class="tc_2">
                    <div class="tc2_top">Lorem ipsum</div>
                    <div class="tc2_bottom">
                        <div class="tc2b_elem">
                            <div class="tc2be_img_area">
                                <img class="tc2beia_img" src="../img/tc2.png?<?=$ver?>" alt="">
                            </div>
                            <div class="tc2be_title">Blah Blah</div>
                            <div class="tc2be_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                        </div>
                        <div class="tc2b_elem">
                            <div class="tc2be_img_area">
                                <img class="tc2beia_img" src="../img/tc2.png?<?=$ver?>" alt="">
                            </div>
                            <div class="tc2be_title">Blah Blah</div>
                            <div class="tc2be_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum..</div>
                        </div>
                        <div class="tc2b_elem">
                            <div class="tc2be_img_area">
                                <img class="tc2beia_img" src="../img/tc2.png?<?=$ver?>" alt="">
                            </div>
                            <div class="tc2be_title">Blah Blah</div>
                            <div class="tc2be_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <div class="translator_contents max_width">
                <div class="tc_3">
                    <div class="tc3_left">
                        <div class="tc3l_title">Blah Blah</div>
                        <div class="tc3l_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                    </div>
                    <div class="tc3_right">
                        <div class="tc3r_row">
                            <div class="tc3rr_left">
                                <div class="tc3rr_icon tc3_icon_url_1"></div>
                            </div>
                            <div class="tc3rr_right">
                                <div class="tc3rrr_title">Blah Blah</div>
                                <div class="tc3rrr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                                <div class="tc3rrr_link link_btn">Blank Link</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc3r_row">
                            <div class="tc3rr_left">
                                <div class="tc3rr_icon tc3_icon_url_1"></div>
                            </div>
                            <div class="tc3rr_right">
                                <div class="tc3rrr_title">Blah Blah</div>
                                <div class="tc3rrr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                                <div class="tc3rrr_link link_btn" onclick="location.href='#'">Blank Link</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc3r_row">
                            <div class="tc3rr_left">
                                <div class="tc3rr_icon tc3_icon_url_1"></div>
                            </div>
                            <div class="tc3rr_right">
                                <div class="tc3rrr_title">Blah Blah</div>
                                <div class="tc3rrr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                                <div class="tc3rrr_link link_btn" onclick="location.href='#'">Blank Link</div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="tc3r_row">
                            <div class="tc3rr_left">
                                <div class="tc3rr_icon tc3_icon_url_1"></div>
                            </div>
                            <div class="tc3rr_right">
                                <div class="tc3rrr_title">Blah Blah</div>
                                <div class="tc3rrr_desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
                                <div class="tc3rrr_link"><a href="#" class="link_btn">Blank Link 1</a> or <a href="#" class="link_btn">Blank Link 2</a></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="tc_4">
                <div class="ic3_top">
                    <div class="ic3t_elem">
                        <img src="../img/tc4.png?<?=$ver?>" alt="">
                        <div class="ic3te_link link_btn" onclick="location.href='reference.php'">Lorem ipsum</div>
                    </div>
                    <div class="ic3t_elem">
                        <img src="../img/tc4.png?<?=$ver?>" alt="">
                        <div class="ic3te_link link_btn" onclick="location.href='reference.php'">Lorem ipsum</div>
                    </div>
                    <div class="ic3t_elem">
                        <img src="../img/tc4.png?<?=$ver?>" alt="">
                        <div class="ic3te_link link_btn" onclick="location.href='reference.php'">Lorem ipsum</div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="ic3_bottom">
                    <div class="ic3b_elem">
                        <img src="../img/tc4.png?<?=$ver?>" alt="">
                        <div class="ic3be_link link_btn" onclick="location.href='reference.php'">Lorem ipsum</div>
                    </div>
                    <div class="ic3b_elem">
                        <img src="../img/tc4.png?<?=$ver?>" alt="">
                        <div class="ic3be_link link_btn" onclick="location.href='reference.php'">Lorem ipsum</div>
                    </div>
                    <div class="ic3b_elem">
                        <img src="../img/tc4.png?<?=$ver?>" alt="">
                        <div class="ic3be_link link_btn" onclick="location.href='reference.php'">Lorem ipsum</div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="ic_7 max_width">
                <div class="ic7_left">
                    <div class="ic7l_title">want quick response? Speak to me directly.</div>
                    <div class="ic7l_desc">check next page.</div>
                    <label class="link_btn" id="contact" onclick="location.href='inquiry.php'">Sample Page</label>
                </div>
                <div class="ic7_right">
                    <div class="ic7r_img ic7ri_url_1"></div>
                    <div class="ic7r_desc">Hello, I'm Yong Gun Park. Do you need my help?</div>
                    <div class=" ic7r_info">
                        <span class="ic7ri_name">Yong Gun Park</span>
                        <span>-</span>
                        <span class="ic7ri_position">PHP, javaScript Web Dev</span>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="ic_8 max_width">
                <div class="ic8_left">
                    <div class="ic8l_title">Lorem ipsum</div>
                    <div class="ic8l_desc">A B C D E F G H I J K L M N O P Q R S T U V W X Y Z</div>
                </div>
                <div class="ic8_right">
                    <label class="link_btn" id="cost">Blank Link</label>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <?php
            include_once("./footer.php");
        ?>
    </body>
</html>

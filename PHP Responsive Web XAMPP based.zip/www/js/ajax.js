function ajax_login(){

    $.ajax({
        url: "../action/login_action.php",
        type: "POST",
        data: {
            user_id: $("#user_id").val(),
            user_pw: $("#user_pw").val()
        }
    }).done(function(returned_data){
        var parsed_r = $.parseJSON(returned_data);
        alert(parsed_r[0].nickname + " login success" + parsed_r[0].id + " welcome");
        $(".login").css("visibility","hidden");
    });
}


function ajax_join(){
    // 유저네임 빈거 채우게하고 중복체크 해야함
    const displayed_captcha = $("#captcha_display").html();
    const input_captcha = $("#captcha_input").val();
    const id_input = $("#new_user_id").val();
    const pw1 = $("#new_user_pw").val();
    const pw2 = $("#new_user_pw_repeat").val();
    if(  id_input.length != 0)
    {
      if( displayed_captcha == input_captcha)
      {
        if(pw1 == pw2 && pw1.length != 0 && pw2.length != 0)
        {
          $.ajax({
              url: "../action/join_action.php",
              type: "POST",
              data: {
                  new_user_id: $("#new_user_id").val(),
                  new_user_pw: $("#new_user_pw").val(),
                  new_user_nick_name: $("#new_user_nick_name").val()
              }
          }).done(function(returned_data){

              alert(returned_data);

              $(".join").css("visibility","hidden");
              $(".login").css("visibility","visible");
          });
        }
        else
        {
          alert(`Password ( ${pw1} ) and Passward repeat  ( ${pw2} )  are not matched or please write passwords`);
          captcha();
        }
      }
      else
      {
        alert("wrong captcha");
        captcha();
      }
    }
    else
    {
        alert("write ID")
        captcha();
    }


}

function ajax_bbs_road(){

        $.ajax({
            url: "../action/bbs_basic_road_action.php",
            type: "POST",
            datatype: "JSON"
        }).done(function(returned_data){

          if(returned_data == false)
          {

          }
          else{
            var parsed = $.parseJSON(returned_data);
            if(parsed.length == 1)
            {
              //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
              var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID:first").html("");
              var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt:first").html("");
              var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin:first").html("");
              var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated:first").html("");
              var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail:first").html("");

              for (var i = 0; i < objClassesID.length; i++) {
                objClassesID.append(parsed[i].nickname)
                objClassesTime.append(parsed[i].time_when)
                objClassesTitle.append(parsed[i].title)
                objClassesMessage.append(parsed[i].message)
                objClassesNumber.append(parsed[i].number)
              }
            }
            else{
              //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
              var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html("");
              var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt").html("");
              var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin ").html("");
              var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated ").html("");
              var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail").html("");

              for (var i = 0; i < objClassesID.length; i++) {
                objClassesID[i].append(parsed[i].nickname)
                objClassesTime[i].append(parsed[i].time_when)
                objClassesTitle[i].append(parsed[i].title)
                objClassesMessage[i].append(parsed[i].message)
                objClassesNumber[i].append(parsed[i].number)
              }
            }
          }

        });

}



function ajax_bbs_extra_road(){
        var road_num = $(".mic2blb_tc_next").attr("value");
        road_num = parseInt(road_num) + 2;
        $(".mic2blb_tc_next").attr("value" ,road_num);
        $.ajax({
            url: "../action/bbs_basic_road_extra_action.php",
            type: "POST",
            data: {
                how_many: road_num
            },
            datatype: "JSON"
        }).done(function(returned_data){

          if(returned_data == false)
          {

          }
          else{
            var obj = $(".mic2blb_tc");
            var location = $(".mic2blb_tc:last");
            var parsed = $.parseJSON(returned_data)

            if(obj.length == parsed.length)
            {
              road_num = parseInt(road_num) - 2;
              $(".mic2blb_tc_next").attr("value" ,road_num);
              // alert("게시글 로딩 맥스");
              //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
              var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html("");
              var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt").html("");
              var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin ").html("");
              var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated ").html("");
              var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail").html("");

              for (var i = 0; i < objClassesID.length; i++) {
                objClassesID[i].append(parsed[i].nickname)
                objClassesTime[i].append(parsed[i].time_when)
                objClassesTitle[i].append(parsed[i].title)
                objClassesMessage[i].append(parsed[i].message)
                objClassesNumber[i].append(parsed[i].number)
              }
            }

            // 게시글 로딩이 홀수인데 글쓰고서 홀수일때 또 추가되서 불러오면 2개불러야하는데 하나불러옴 이거 디테일수정
            else if (obj.length != parsed.length && parsed.length%2 == 1) {
              // alert("게시글 로딩 홀수");
              road_num = parseInt(road_num) - 1;
              $(".mic2blb_tc_next").attr("value" ,road_num);
              $(location).clone().insertAfter(location);
              //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
              var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html("");
              var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt").html("");
              var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin ").html("");
              var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated ").html("");
              var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail").html("");

              for (var i = 0; i < objClassesID.length; i++) {
                objClassesID[i].append(parsed[i].nickname + i)
                objClassesTime[i].append(parsed[i].time_when)
                objClassesTitle[i].append(parsed[i].title)
                objClassesMessage[i].append(parsed[i].message)
                objClassesNumber[i].append(parsed[i].number)
              }


          }
          else{
            // alert("게시글 로딩 2개추가");
            $(location).clone().insertAfter(location);
            $(location).clone().insertAfter(location);
            //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
            var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html("");
            var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt").html("");
            var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin ").html("");
            var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated ").html("");
            var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail").html("");

            for (var i = 0; i < objClassesID.length; i++) {
              objClassesID[i].append(parsed[i].nickname + i)
              objClassesTime[i].append(parsed[i].time_when)
              objClassesTitle[i].append(parsed[i].title)
              objClassesMessage[i].append(parsed[i].message)
              objClassesNumber[i].append(parsed[i].number)
          }
        }
      }
    });
}





function ajax_bbs_write(){
    const title = $("#new_bbs_title").val();
    const message = $("#new_bbs_message").val();
    var road_num = $(".mic2blb_tc_next").attr("value");
    if(title != "")
    {
      if(message != "")
      {
        $.ajax({
            url: "../action/bbs_write_action.php",
            type: "POST",
            data: {
                new_bbs_title: title,
                new_bbs_message: message,
                how_many: road_num
            },
            datatype: "JSON"
        }).done(function(returned_data){

          var parsed = $.parseJSON(returned_data);
          if(parsed.length == 1)
          {
            //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
            var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID:first").html("");
            var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt:first").html("");
            var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin:first").html("");
            var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated:first").html("");
            var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail:first").html("");

            for (var i = 0; i < objClassesID.length; i++) {
              objClassesID.append(parsed[i].nickname)
              objClassesTime.append(parsed[i].time_when)
              objClassesTitle.append(parsed[i].title)
              objClassesMessage.append(parsed[i].message)
              objClassesNumber.append(parsed[i].number)
            }
          }
          else{
            //$(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html(parsed[0].nickname);
            var objClassesID = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_ID").html("");
            var objClassesTime = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_info .mic2blbtcti_Time .mic2blbtctit_ymdt").html("");
            var objClassesTitle = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_origin ").html("");
            var objClassesMessage = $(".mic2blb_tc .mic2blb_tc_mid .mic2blbtcm_translated ").html("");
            var objClassesNumber = $(".mic2blb_tc .mic2blb_tc_top .mic2blbtct_detail").html("");

            for (var i = 0; i < objClassesID.length; i++) {
              objClassesID[i].append(parsed[i].nickname)
              objClassesTime[i].append(parsed[i].time_when)
              objClassesTitle[i].append(parsed[i].title)
              objClassesMessage[i].append(parsed[i].message)
              objClassesNumber[i].append(parsed[i].number)
            }
          }

        });

      }
      else
      {
        alert("please write message");
      }

    }
    else
    {
      alert("please write title");
    }
}

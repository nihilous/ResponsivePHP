function captcha(){
  var capcharNum = new Array();
  var capcharData = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
  var  how_long_capchar = 6;
  var capcharLetter = new Array();

  for(var i=0; i<how_long_capchar; i++) {
    capcharNum[i] = Math.floor(Math.random() * 62);
    capcharLetter[i] = capcharData[capcharNum[i]];
  }
  $("#captcha_display").html("");
  $("#captcha_display").append(capcharLetter);
}

$(window).on("load", function(){

    ajax_bbs_road();



    $(".ham").on("click", function(){
        $(".mob_side_menus").toggle();
    });

    $(".side_close_button").on("click", function(){
        $(".mob_side_menus").toggle();
    });

    $("#login").on("click", function(){
        $(".pass_find").css("visibility","hidden");
        $(".login").css("visibility","visible");

    });

    $("#affiliate_login").on("click", function(){
        $(".pass_find").css("visibility","hidden");
        $(".login").css("visibility","visible");

    });

    $("#mob_login").on("click", function(){
        $(".pass_find").css("visibility","hidden");
        $(".login").css("visibility","visible");
    });

    $(".lb_close").on("click", function(){
        $(".login").css("visibility","hidden");
    });

    $(".lb_lost_find").on("click", function(){
        $(".login").css("visibility","hidden");
        $(".pass_find").css("visibility","visible");
    });



    $(".pfb_login_back").on("click", function(){
        $(".pass_find").css("visibility","hidden");
        $(".login").css("visibility","visible");
    });

    $(".pfb_close").on("click", function(){
        $(".pass_find").css("visibility","hidden");
    });

    $(".lb_join").on("click", function(){
        $(".login").css("visibility","hidden");
        $(".join").css("visibility","visible");
        captcha();
    });

    $(".jbb_login_back").on("click", function(){
        $(".join").css("visibility","hidden");
        $(".login").css("visibility","visible");
    });

    $(".jbt_close").on("click", function(){
        $(".join").css("visibility","hidden");
    });


    /*문의하기 전화번호 표시*/
    $(".qc2rc_reg").on("click", function(){
        $(".qc_phone_digit").toggle();
    });

    $(".qcpdt_close").on("click", function(){
        $(".qc_phone_digit").toggle();
    });



    //인덱스 .ic1l_Desc 쪽 문구 변경
    // 언어코드 추출
    var indexLang = $(".ic1l_Desc").attr("value");
    var index_num = 0;
    function index_desc(){
        index_num++;
        if(index_num == 3){
            index_num = 0;
        }
        switch (indexLang) {

            /*언어 코드를 value에서 추출후 체크*/
            case "kor":
                  switch (index_num) {
                      case 0: $(".ic1l_Desc").html("박용건")
                          break;
                      case 1: $(".ic1l_Desc").html("입니다")
                          break;
                      case 2: $(".ic1l_Desc").html("반가워요")
                          break;
                      default:
                          break;
                  }
                break;
            case "eng":
                  switch (index_num) {
                      case 0: $(".ic1l_Desc").html("Moi")
                          break;
                      case 1: $(".ic1l_Desc").html("Olen")
                          break;
                      case 2: $(".ic1l_Desc").html("Yong Gun")
                          break;
                      default:
                          break;
                  }
                break;
                case "jpn":
                      switch (index_num) {
                          case 0: $(".ic1l_Desc").html("ヨンサマ")
                              break;
                          case 1: $(".ic1l_Desc").html("こんにちは")
                              break;
                          case 2: $(".ic1l_Desc").html("うれしい")
                              break;
                          default:
                              break;
                      }
                    break;
            default:
                break;
        }
    }
    setInterval(function(){ index_desc(); }, 1000);







    //인덱스쪽 클릭시 내부요소 변환
    $(".ic4wle_elem").on("click", function(){
        var ic4wlLang = $(".ic4wle_elem").attr("value");
        var elemID = $(this).attr("id");
        var elemArr = $(".ic4wle_elem");
        for (var i = 0; i < elemArr.length; i++) {
            if($(elemArr[i]).attr("id") == elemID){
                $(elemArr[i]).css("background-color", "red");

                switch (ic4wlLang) {
                    case "kor":
                    switch (i) {
                        case 0:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_1.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_1.png")
                              $(".ic4wlscc_desc").html("빨리 배우고 이해가 빠르네");
                              $(".ic4wlscc_name").html("이석진");
                              $(".ic4wlscc_company").html("Brave Lead 개발");
                              indexElemNum = i+1;
                              break;
                        case 1:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_2.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_2.png")
                              $(".ic4wlscc_desc").html("창조적이고 같이 일하기 재미있음.");
                              $(".ic4wlscc_name").html("양경주");
                              $(".ic4wlscc_company").html("꼬망팩토리");
                              indexElemNum = i+1;
                              break;
                        case 2:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_3.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_3.png")
                              $(".ic4wlscc_desc").html("밝고 친근하고, 남들 잘도와주고, 쉽게배움.");
                              $(".ic4wlscc_name").html("Rikka Mäklin");
                              $(".ic4wlscc_company").html("와이프");
                              indexElemNum = i+1;
                              break;

                        case 3:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_4.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_4.png")
                              $(".ic4wlscc_desc").html("잘해, 근데 자바는 하지마, 취직못해");
                              $(".ic4wlscc_name").html("김태영");
                              $(".ic4wlscc_company").html("결혼식사회, 메가스터디 개발자");
                              indexElemNum = i+1;
                              break;

                        case 4:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_5.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_5.png")
                              $(".ic4wlscc_desc").html("빈칸");
                              $(".ic4wlscc_name").html("빈칸");
                              $(".ic4wlscc_company").html("빈칸.");
                              indexElemNum = i+1;
                              break;

                        case 5:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_6.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_6.png")
                              $(".ic4wlscc_desc").html("빈칸");
                              $(".ic4wlscc_name").html("빈칸");
                              $(".ic4wlscc_company").html("빈칸.");
                              indexElemNum = i+1;
                              break;

                        default:
                              break;
                    }
                        break;
                    case "eng":
                    switch (i) {
                        case 0:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_1.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_1.png")
                              $(".ic4wlscc_desc").html("Yong Gun has  good learning curve, and did work with efficiency.");
                              $(".ic4wlscc_name").html("Seok Jin Lee");
                              $(".ic4wlscc_company").html("Brave Lead Dev");
                              indexElemNum = i+1;
                              break;

                        case 1:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_2.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_2.png")
                              $(".ic4wlscc_desc").html("Creative and Funny to work with.");
                              $(".ic4wlscc_name").html("Kyung Joo Yang");
                              $(".ic4wlscc_company").html("Kkomang Factory");
                              indexElemNum = i+1;
                              break;

                        case 2:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_3.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_3.png")
                              $(".ic4wlscc_desc").html("Bright and Friendly, willing to Help Other, Learn Easily.");
                              $(".ic4wlscc_name").html("Rikka Mäklin");
                              $(".ic4wlscc_company").html("Wife");
                              indexElemNum = i+1;
                              break;

                        case 3:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_4.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_4.png")
                              $(".ic4wlscc_desc").html("Would do well. but don't do JAVA. you can't get a job.");
                              $(".ic4wlscc_name").html("Tae Young Kim");
                              $(".ic4wlscc_company").html("Bestman, Megastudy Dev");
                              indexElemNum = i+1;
                              break;

                        case 4:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_5.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_5.png")
                              $(".ic4wlscc_desc").html("Blank");
                              $(".ic4wlscc_name").html("Blank");
                              $(".ic4wlscc_company").html("Blank");
                              indexElemNum = i+1;
                              break;

                        case 5:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_6.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_6.png")
                              $(".ic4wlscc_desc").html("Blank");
                              $(".ic4wlscc_name").html("Blank");
                              $(".ic4wlscc_company").html("Blank");
                              indexElemNum = i+1;
                              break;

                        default:
                              break;
                    }
                    break;
                    case "jpn":
                    switch (i) {
                        case 0:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_1.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_1.png")
                              $(".ic4wlscc_desc").html("理解が速く、早く学ぶ.");
                              $(".ic4wlscc_name").html("イ・ソクジン");
                              $(".ic4wlscc_company").html("ブレーブシニア Dev");
                              indexElemNum = i+1;
                              break;

                        case 1:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_2.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_2.png")
                              $(".ic4wlscc_desc").html("クリエイティブで一緒に働くと楽しいです.");
                              $(".ic4wlscc_name").html("ヤン・ギョンジュ");
                              $(".ic4wlscc_company").html("コマンファクトリー");
                              indexElemNum = i+1;
                              break;

                        case 2:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_3.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_3.png")
                              $(".ic4wlscc_desc").html("よく、JAVAはしないでください.");
                              $(".ic4wlscc_name").html("キム・テヨン");
                              $(".ic4wlscc_company").html("ベストフレンド, メガスタディ Dev");
                              indexElemNum = i+1;
                              break;

                        case 3:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_4.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_4.png")
                              $(".ic4wlscc_desc").html("明るい性格で親しみやすく、人をよく助け、学ぶことを容易にする.");
                              $(".ic4wlscc_name").html("リカ・マクリン");
                              $(".ic4wlscc_company").html("ワイプ");
                              indexElemNum = i+1;
                              break;

                        case 4:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_5.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_5.png")
                              $(".ic4wlscc_desc").html("内容なし");
                              $(".ic4wlscc_name").html("内容なし");
                              $(".ic4wlscc_company").html("内容なし");
                              indexElemNum = i+1;
                              break;

                        case 5:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_6.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_6.png")
                              $(".ic4wlscc_desc").html("内容なし");
                              $(".ic4wlscc_name").html("内容なし");
                              $(".ic4wlscc_company").html("内容なし");
                              indexElemNum = i+1;
                              break;

                        default:
                              break;
                    }
                    break;
                    default:
                        break;
                }
            }
            else{
                $(elemArr[i]).css("background-color", "#4e81ff");
            }
        }
    });

    //인덱스쪽 클릭시 내부요소 변환2 회사설명 클릭시
    var indexElemNum = 1;
    $(".ic4wls_cont").on("click", function(){

        var ic4wlLang = $(".ic4wle_elem").attr("value");
        var elemID = $(".ic4wle_elem").attr("id");
        var elemArr = $(".ic4wle_elem");

        /*가장 마지막 버튼 클릭후 글귀 클릭시*/
        if(indexElemNum == elemArr.length){
            indexElemNum = 0;
        }
        for (var i = 0; i < elemArr.length; i++) {
          if(indexElemNum == i){
            $(elemArr[indexElemNum]).css("background-color", "red");
                switch (ic4wlLang) {
                    case "kor":
                    switch (indexElemNum) {
                        case 0:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_1.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_1.png")
                              $(".ic4wlscc_desc").html("빨리 배우고 이해가 빠르네");
                              $(".ic4wlscc_name").html("이석진");
                              $(".ic4wlscc_company").html("Brave Lead 개발");
                            break;

                        case 1:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_2.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_2.png")
                              $(".ic4wlscc_desc").html("창조적이고 같이 일하기 재미있음.");
                              $(".ic4wlscc_name").html("양경주");
                              $(".ic4wlscc_company").html("꼬망팩토리");
                            break;

                        case 2:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_3.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_3.png")
                              $(".ic4wlscc_desc").html("밝고 친근하고, 남들 잘도와주고, 쉽게배움.");
                              $(".ic4wlscc_name").html("Rikka Mäklin");
                              $(".ic4wlscc_company").html("와이프");
                            break;

                        case 3:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_4.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_4.png")
                            $(".ic4wlscc_desc").html("잘해, 근데 자바는 하지마, 취직못해");
                            $(".ic4wlscc_name").html("김태영");
                            $(".ic4wlscc_company").html("결혼식사회, 메가스터디 개발자");
                            break;

                        case 4:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_5.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_5.png")
                            $(".ic4wlscc_desc").html("빈칸");
                            $(".ic4wlscc_name").html("빈칸");
                            $(".ic4wlscc_company").html("빈칸.");
                            break;

                        case 5:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_6.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_6.png")
                            $(".ic4wlscc_desc").html("빈칸");
                            $(".ic4wlscc_name").html("빈칸");
                            $(".ic4wlscc_company").html("빈칸.");
                            break;

                        default:
                              break;
                    }
                    break;
                    case "eng":
                    switch (indexElemNum) {
                        case 0:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_1.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_1.png")
                              $(".ic4wlscc_desc").html("Yong Gun has  good learning curve, and did work with efficiency.");
                              $(".ic4wlscc_name").html("Seok Jin Lee");
                              $(".ic4wlscc_company").html("Brave Lead Dev");
                            break;

                        case 1:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_2.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_2.png")
                              $(".ic4wlscc_desc").html("Creative and Funny to work with.");
                              $(".ic4wlscc_name").html("Kyung Joo Yang");
                              $(".ic4wlscc_company").html("Kkomang Factory");
                            break;

                        case 2:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_3.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_3.png")
                              $(".ic4wlscc_desc").html("Bright and Friendly, willing to Help Other, Learn Easily.");
                              $(".ic4wlscc_name").html("Rikka Mäklin");
                              $(".ic4wlscc_company").html("Wife");
                            break;

                        case 3:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_4.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_4.png")
                            $(".ic4wlscc_desc").html("Would do well. but don't do JAVA. you can't get a job.");
                            $(".ic4wlscc_name").html("Tae Young Kim");
                            $(".ic4wlscc_company").html("Bestman, Megastudy Dev");
                            break;

                        case 4:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_5.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_5.png")
                            $(".ic4wlscc_desc").html("Blank");
                            $(".ic4wlscc_name").html("Blank");
                            $(".ic4wlscc_company").html("Blank");
                            break;

                        case 5:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_6.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_6.png")
                            $(".ic4wlscc_desc").html("Blank");
                            $(".ic4wlscc_name").html("Blank");
                            $(".ic4wlscc_company").html("Blank");
                            break;

                        default:
                              break;
                    }
                    break;
                    case "jpn":
                    switch (indexElemNum) {
                        case 0:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_1.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_1.png")
                              $(".ic4wlscc_desc").html("理解が速く、早く学ぶ.");
                              $(".ic4wlscc_name").html("イ・ソクジン");
                              $(".ic4wlscc_company").html("ブレーブシニア Dev");
                            break;

                        case 1:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_2.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_2.png")
                              $(".ic4wlscc_desc").html("クリエイティブで一緒に働くと楽しいです.");
                              $(".ic4wlscc_name").html("ヤン・ギョンジュ");
                              $(".ic4wlscc_company").html("コマンファクトリー");
                            break;

                        case 2:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_3.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_3.png")
                              $(".ic4wlscc_desc").html("よく、JAVAはしないでください.");
                              $(".ic4wlscc_name").html("キム・テヨン");
                              $(".ic4wlscc_company").html("ベストフレンド, メガスタディ Dev");
                            break;

                        case 3:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_4.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_4.png")
                              $(".ic4wlscc_desc").html("明るい性格で親しみやすく、人をよく助け、学ぶことを容易にする.");
                              $(".ic4wlscc_name").html("リカ・マクリン");
                              $(".ic4wlscc_company").html("ワイプ");
                            break;

                        case 4:
                              $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_5.png')")
                              $(".ic4wlcir2_img").attr("src","../img/ic4_c_5.png")
                              $(".ic4wlscc_desc").html("内容なし");
                              $(".ic4wlscc_name").html("内容なし");
                              $(".ic4wlscc_company").html("内容なし");
                            break;

                        case 5:
                            $(".ic4wlsc_img_rounder").css("background-image","url('../img/ic4_p_6.png')")
                            $(".ic4wlcir2_img").attr("src","../img/ic4_c_6.png")
                            $(".ic4wlscc_desc").html("Blank");
                            $(".ic4wlscc_name").html("Blank");
                            $(".ic4wlscc_company").html("Blank");
                            break;

                        default:
                              break;
                    }
                    break;
                    default:
                        break;
                }
                }
                else{
                    $(elemArr[i]).css("background-color", "#4e81ff");
                }
            }

        indexElemNum++;
        if(indexElemNum == elemArr.length){
            indexElemNum = 0;
        }
    });



    //FAQ 클릭시 내부요소 변환
    $(".faqcbc_desc").on("click", function(){
        var elemID = "#" + $(this).attr("id");
        $(elemID + " .faqcbcd_answer").toggle();
        var src = $(elemID + " .faqcbcdq_right").attr("src");
        var ver = "?" + $(elemID + " .faqcbcdq_right").attr("value");
        if(src == "../img/faq.png" + ver){
            $(elemID + " .faqcbcdq_right").attr("src","../img/faq2.png" + ver);
        }
        else{
            $(elemID + " .faqcbcdq_right").attr("src","../img/faq.png" + ver);
        }
    });

    $(window).resize(function(){
        // 클릭해서 켜둔상태라면 로그인박스나
        var disCheck = $(".mob_side_menus").css("display");
        if(disCheck == "block"){
            if (screen.width>=1200) {
                $(".mob_side_menus").css("display","none");

                // 로그인창 켜져있으면
                if($(".login").css("visibility") == "visible" ){
                  $(".login").css("visibility", "hidden")
                }

            }
              else  {
                $(".mob_side_menus").css("display","block");
            }
        }
    });




});

<?php
  include_once('../inc/ver.php');
    /*
    if($_session["login_stay"] != true)
    {
      echo("Please Login Again");
    }

    else
    */
    {

      $dbConnect = mysqli_connect(
          'localhost',
          'root',
          '',
          'portfolio'
      );

      /*
      mysqli_query($dbConnect, "set session character_set_connection=utf8;");
      mysqli_query($dbConnect, "set session character_set_results=utf8;");
      mysqli_query($dbConnect, "set session character_set_client=utf8;");
      */


      //


      //sample

      $user_nick_name = $_session["user_name"];
      $new_title = $_POST['new_bbs_title'];
      $new_message = $_POST['new_bbs_message'];
      $how_many_posts = $_POST['how_many'];

      htmlspecialchars($new_title, ENT_QUOTES, 'UTF-8');
      htmlspecialchars($new_message, ENT_QUOTES, 'UTF-8');

      $sql = "insert into bbs
      ( nickname, title , time_when, message, show_or_delete )
      values
      (" . "\"" .$user_nick_name. "\"" . "," . "\"" .$new_title. "\"" . "," . "now()" . "," . "\"" .$new_message. "\"" . ", true )";
      $db_return1 = mysqli_query($dbConnect, $sql);
      //echo($db_return1);is 1

      if($db_return1 != true){
        echo "insert failed";
        exit;
      }


      // $sql = "select * from bbs where number in (select max(number) from bbs)";
      $sql = "select * from bbs order by number DESC limit " . $how_many_posts;
      $db_return2 = mysqli_query($dbConnect, $sql);
      $write_result_OBJ_1 = mysqli_fetch_all($db_return2, MYSQLI_ASSOC);
      // $write_result_OBJ_1 = mysqli_fetch_array($db_return2);
      /*
      $php_arrayed_result = array("number" => $write_result_OBJ_1[0]["number"],
      "nickname" => $write_result_OBJ_1[0]["nickname"],
      "title" => $write_result_OBJ_1[0]["title"],
      "time_when" => $write_result_OBJ_1[0]["time_when"],
      "message" => $write_result_OBJ_1[0]["message"],
      "show_or_delete" => $write_result_OBJ_1[0]["show_or_delete"]);
      */
      //{"number":"109","nickname":"\ud14c\uc2a4\ud1301","title":"bbs title","time_when":"2021-10-19 21:25:20","message":"bbs msg","show_or_delete":"1"}]
      echo (json_encode($write_result_OBJ_1));
    }

    mysqli_close($dbConnect);


?>

<?php
  include_once('../inc/ver.php');
    $dbConnect = mysqli_connect(
        'localhost',
        'root',
        '',
        'portfolio'
    );
    /*
    mysqli_query($dbConnect, "set session character_set_connection=utf8;");
    mysqli_query($dbConnect, "set session character_set_results=utf8;");
    mysqli_query($dbConnect, "set session character_set_client=utf8;");
    */

    $id = $_POST['user_id'];
    // $pw = $_POST['user_pw'];
    $pw = crypt( $_POST['user_pw'], md5($_POST['user_pw']));

    htmlspecialchars($id, ENT_QUOTES, 'UTF-8');
    htmlspecialchars($pw, ENT_QUOTES, 'UTF-8');

    $sql = "select * from user where id= " . "\"" .$id. "\"";
    $db_return = mysqli_query($dbConnect, $sql);
    $result_OBJ = mysqli_fetch_all($db_return, MYSQLI_ASSOC);

    if(count($result_OBJ)==0)
    {
        echo " ID " .$id ." Doesn't Exists.";
        session_destroy();
    }
    else
    {
      if($result_OBJ[0]["pw"] != $pw)
      {
          if(count($result_OBJ) == 1)
          {
              echo "Written Password is " . $pw;
              echo $id ." Your Password is Wrong";
              session_destroy();
          }
      }
      else {
          echo(json_encode($result_OBJ));

          $_session["user_name"] = $result_OBJ[0]["nickname"];
          $_session["login_stay"] = true;

      }
    }

    mysqli_close($dbConnect);
?>

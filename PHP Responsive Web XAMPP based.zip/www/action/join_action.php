<?php
  include_once('../inc/ver.php');
    $dbConnect = mysqli_connect(
        'localhost',
        'root',
        '',
        'portfolio'
    );
    /*
    mysqli_query($dbConnect, "set session character_set_connection=utf8;");
    mysqli_query($dbConnect, "set session character_set_results=utf8;");
    mysqli_query($dbConnect, "set session character_set_client=utf8;");
    */

    $new_id = $_POST['new_user_id'];
    // $new_pw = $_POST['new_user_pw'];
    $new_pw = crypt( $_POST['new_user_pw'], md5($_POST['new_user_pw']));
    $new_nick_name = $_POST['new_user_nick_name'];


    htmlspecialchars($new_id, ENT_QUOTES, 'UTF-8');
    htmlspecialchars($new_pw, ENT_QUOTES, 'UTF-8');

    $sql = "select * from user where id= " . "\"" .$new_id. "\"";
    $db_return1 = mysqli_query($dbConnect, $sql);
    $join_result_OBJ_1 = mysqli_fetch_all($db_return1, MYSQLI_ASSOC);

    if(count($join_result_OBJ_1)!=0)
    {
        echo "That ID Already Exists.";
    }
    else
    {
      $sql = "select * from user where nickname= " . "\"" .$new_nick_name. "\"";
      $db_return2 = mysqli_query($dbConnect, $sql);
      $join_result_OBJ_2 = mysqli_fetch_all($db_return2, MYSQLI_ASSOC);

      if(count($join_result_OBJ_2)!=0)
      {
        echo "That Nick Name Already Exists.";
      }
      else{
        $sql = "insert into user ( id, pw, nickname ) values (" . "\"" .$new_id. "\"". "," . "\"" .$new_pw. "\"". "," . "\"" .$new_nick_name. "\"". ")";
        $db_return3 = mysqli_query($dbConnect, $sql);
        echo($db_return3);

        $sql = "select * from user where id= " . "\"" .$new_id. "\"";
        $db_return4 = mysqli_query($dbConnect, $sql);
        $join_result_OBJ_3 = mysqli_fetch_all($db_return4, MYSQLI_ASSOC);

        echo "New ID is " . $join_result_OBJ_3[0]["id"];
        echo "Welcome " . $join_result_OBJ_3[0]["nickname"];

      }

    }

    mysqli_close($dbConnect);




?>

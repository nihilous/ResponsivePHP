<?php
  include_once('../inc/ver.php');
    {
      $dbConnect = mysqli_connect(
          'localhost',
          'root',
          '',
          'portfolio'
      );
      // $sql = "select * from bbs where number in (select max(number) from bbs)";

      $sql = "select * from bbs order by number DESC limit 2";
      $db_return2 = mysqli_query($dbConnect, $sql);
      $write_result_OBJ_1 = mysqli_fetch_all($db_return2, MYSQLI_ASSOC);
      // $write_result_OBJ_1 = mysqli_fetch_array($db_return2);
      /*
      $php_arrayed_result = array("number" => $write_result_OBJ_1[0]["number"],
      "nickname" => $write_result_OBJ_1[0]["nickname"],
      "title" => $write_result_OBJ_1[0]["title"],
      "time_when" => $write_result_OBJ_1[0]["time_when"],
      "message" => $write_result_OBJ_1[0]["message"],
      "show_or_delete" => $write_result_OBJ_1[0]["show_or_delete"]);
      */
      //{"number":"109","nickname":"\ud14c\uc2a4\ud1301","title":"bbs title","time_when":"2021-10-19 21:25:20","message":"bbs msg","show_or_delete":"1"}]
      if($write_result_OBJ_1 == false)
      {
        echo(false);
        exit;
      }
      echo (json_encode($write_result_OBJ_1));
    }

    mysqli_close($dbConnect);

?>
